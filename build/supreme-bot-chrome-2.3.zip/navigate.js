var t0 = performance.now();

var url_split = window.location.href.split("/");

// if keyword enabled, navigate to category from shopfront
if (url_split[url_split.length-1] == "shop") {
	chrome.storage.sync.get({
		runnable: '',
		kw_enabled: '',
		category: ''
	}, 
	function(items) {
	    if (items.kw_enabled && items.runnable) {
	    	window.location.href = "https://supremenewyork.com/shop/all/" + items.category;
	    }
	});
}

// if keyword enabled, navigate to first matched item from category page
if (url_split[url_split.length-3] == "shop") {
	chrome.storage.sync.get({
		kw_enabled: '',
		keywords: ''
	},
	function(items) {
		if (items.kw_enabled) {
			var keywords = items.keywords.split(" ");
			foundItems = []

			var aTags = document.getElementsByTagName("a");
			for (var i = 0; i < aTags.length; i++) {
				if (aTags[i].textContent.toLowerCase().includes(keywords[0].toLowerCase())) {
						foundItems.push(aTags[i]);
				}
			}

			for (word in keywords) {
				temp = []
				for (i in foundItems) {
					if (foundItems[i].textContent.toLowerCase().includes(keywords[word].toLowerCase())) {
						temp.push(foundItems[i])
					}
				}
				foundItems = temp;
			}
			// .click() does not trigger DOMContentLoaded here for some reason
			window.location.href = foundItems[0].href;
		}
	});
}

// if on item page, select colour, size and navigate to checkout
// regex to verify 9 character alphanumeric string
if (window.location.href.includes("shop/") && /^([a-zA-Z0-9]{9})$/.test(url_split[url_split.length-1])) {
	chrome.storage.sync.get({
		size: '',
		kw_enabled: '',
		colour: ''
	}, 
	function(items) {
		// select colour
		if (items.kw_enabled) {
			colours = items.colour.split(" ");
			var colTags = document.getElementsByTagName("a");
			var foundItems = [];
			for (var i = 0; i < colTags.length; i++) {
				if (colTags[i].getAttribute("data-style-name")) {
					foundItems.push(colTags[i]);
				}
			}
			foundColours = [];
			for (col in colours) {
				for (elem in foundItems) {
					if (foundItems[elem].getAttribute("data-style-name").toLowerCase() == colours[col].toLowerCase()) {
						foundColours.push(foundItems[elem]);
					}
				}
			}
			foundColours[0].click();
		}

		// select size
		setTimeout(function() {
			var opTags = document.getElementsByTagName("option");
			for (var i = 0; i < opTags.length; i++) {
				if (opTags[i].textContent == items.size) {
					sizeFound = opTags[i];
					break;
				}
			}
			document.getElementById("size").value = sizeFound.value;
		}, 100);
	});

	// add to basket
	setTimeout(function(){document.getElementsByName("commit")[0].click();}, 100);

	// go to checkout
	var aTags = document.getElementsByTagName("a");
	for (var i = 0; i < aTags.length; i++) {
		if (aTags[i].textContent == "checkout now") {
			found = aTags[i];
			break;
		}
	}
	setTimeout(function(){found.click();}, 100);
}

// if on checkout page, autofill data
if (window.location.href.includes("checkout")) {
  	chrome.storage.sync.get({
    	name: '',
    	email: '',
    	phone: '',
    	address: '',
    	city: '',
    	zip: '',
    	card_type: '',
    	card_no: '',
    	expiry_month: '',
    	expiry_year: '',
    	cvv: '',
    	autoco: ''
	  }, 
	  function(items) {
	    document.getElementById('order_billing_name').value = items.name;
	    document.getElementById("order_email").value = items.email;
	    document.getElementById("order_tel").value = items.phone;
	    document.getElementById("bo").value = items.address;
	    document.getElementById("order_billing_city").value = items.city;
	    document.getElementById("order_billing_zip").value = items.zip;
	    document.getElementById("cnb").value = items.card_no;
	    document.getElementById("credit_card_type").value = items.card_type;
	    document.getElementById("credit_card_month").value = items.expiry_month;
	    document.getElementById("credit_card_year").value = items.expiry_year;
	    document.getElementById("vval").value = items.cvv;

	    document.getElementsByName("order[terms]")[1].parentElement.className = "icheckbox_minimal checked";
	    document.getElementsByName("order[terms]")[0].checked = true;
		document.getElementsByName("order[terms]")[1].checked = true;

		if (items.autoco) {
			setTimeout(function(){document.getElementsByName("commit")[0].click();}, 2100);
		}

		chrome.storage.sync.set({
			runnable: false
		},
		function() {});
	});
}
console.log((performance.now() - t0).toFixed(2) + " ms");