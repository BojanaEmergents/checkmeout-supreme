document.addEventListener('DOMContentLoaded', function() {
    var link = document.getElementById('run');
    // onClick's logic below:
    link.addEventListener('click', function() {
        chrome.tabs.executeScript(null, {file: "navigate.js"});
    });
});