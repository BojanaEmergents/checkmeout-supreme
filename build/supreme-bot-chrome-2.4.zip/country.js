document.addEventListener('DOMContentLoaded', function() {
	setEU();
});

document.getElementById("eu").addEventListener("click", setEU);
document.getElementById("us").addEventListener("click", setUS);
document.getElementById("jp").addEventListener("click", setJP);

function setEU() {
	chrome.storage.sync.set({
		region: "eu"
	});
	document.getElementById("keyword-section").hidden = false;

	document.getElementById("us-state").hidden = true;
}

function setUS() {
	chrome.storage.sync.set({
		region: "us"
	});
	document.getElementById("keyword-section").hidden = false;

	document.getElementById("us-state").hidden = false;
}

function setJP() {
	chrome.storage.sync.set({
		region: "jp"
	});
	document.getElementById("keyword-section").hidden = true;

	document.getElementById("us-state").hidden = true;
}