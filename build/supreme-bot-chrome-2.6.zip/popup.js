 document.addEventListener('DOMContentLoaded', function() {
    var link = document.getElementById('run');
    var optspage = document.getElementById("opts");
    // onClick's logic below:
    link.addEventListener('click', function() {
    	chrome.storage.sync.set({
    		runnable: true
    	},
    	function() {});
        chrome.tabs.executeScript(null, {file: "navigate.js"});
    });
    optspage.addEventListener('click', function() {
    	chrome.tabs.create({url: "options.html"});
    });
});