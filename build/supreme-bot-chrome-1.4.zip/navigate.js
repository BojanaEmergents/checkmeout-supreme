var url_split = window.location.href.split("/");
if (window.location.href.includes("shop/") && /^([a-zA-Z0-9]{9})$/.test(url_split[url_split.length-1])) {
	chrome.storage.sync.get({
		size: ''
	}, 
	function(items) {
		var opTags = document.getElementsByTagName("option");
		for (var i = 0; i < opTags.length; i++) {
			if (opTags[i].textContent == items.size) {
				sizeFound = opTags[i];
				break;
			}
		}
		document.getElementById("size").value = sizeFound.value;
	});

	setTimeout(function(){document.getElementsByName("commit")[0].click();}, 100);

	var aTags = document.getElementsByTagName("a");
	for (var i = 0; i < aTags.length; i++) {
		if (aTags[i].textContent == "checkout now") {
			found = aTags[i];
			break;
		}
	}

	setTimeout(function(){found.click();}, 250);
}

if (window.location.href.includes("checkout")) {
  	chrome.storage.sync.get({
    	name: '',
    	email: '',
    	phone: '',
    	address: '',
    	city: '',
    	zip: '',
    	card_type: '',
    	card_no: '',
    	expiry_month: '',
    	expiry_year: '',
    	cvv: '',
    	autoco: ''
	  }, 
	  function(items) {
	    document.getElementById('order_billing_name').value = items.name;
	    document.getElementById("order_email").value = items.email;
	    document.getElementById("order_tel").value = items.phone;
	    document.getElementById("bo").value = items.address;
	    document.getElementById("order_billing_city").value = items.city;
	    document.getElementById("order_billing_zip").value = items.zip;
	    document.getElementById("cnb").value = items.card_no;
	    document.getElementById("credit_card_type").value = items.card_type;
	    document.getElementById("credit_card_month").value = items.expiry_month;
	    document.getElementById("credit_card_year").value = items.expiry_year;
	    document.getElementById("vval").value = items.cvv;

	    document.getElementsByName("order[terms]")[1].parentElement.className = "icheckbox_minimal checked";
	    document.getElementsByName("order[terms]")[0].checked = true;
		document.getElementsByName("order[terms]")[1].checked = true;

		if (items.autoco) {
			setTimeout(function(){document.getElementsByName("commit")[0].click();}, 2001);
		}
	});
}