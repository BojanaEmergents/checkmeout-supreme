// Saves options to chrome.storage
function save_options() {
  var name = document.getElementById("name").value;
  var email = document.getElementById("email").value;
  var phone = document.getElementById("phone").value;
  var address = document.getElementById("address").value;
  var city = document.getElementById("city").value;
  var zip = document.getElementById("zip").value;
  var card_type = document.getElementById("card_type").value;
  var card_no = document.getElementById("card_no").value;
  var expiry_month = document.getElementById("expiry_month").value;
  var expiry_year = document.getElementById("expiry_year").value;
  var cvv = document.getElementById("cvv").value;
  var size = document.getElementById("size").value;
  var autoco = document.getElementById("autoco").checked;

  chrome.storage.sync.set({
    name: name,
    email: email,
    phone: phone,
    address: address,
    city: city,
    zip: zip,
    card_type: card_type,
    card_no: card_no,
    expiry_month: expiry_month,
    expiry_year: expiry_year,
    cvv: cvv,
    size: size,
    autoco: autoco
  }, 
  function() {
    // Update status to let user know options were saved.
    var status = document.getElementById('status');
    status.textContent = 'Options saved.';
    setTimeout(function() {
      status.textContent = '';
    }, 1500);
  });
}

// Restores select box and checkbox state using the preferences
// stored in chrome.storage.
function restore_options() {
  // Use default value color = 'red' and likesColor = true.
  chrome.storage.sync.get({
    name: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    zip: '',
    card_type: '',
    card_no: '',
    expiry_month: '',
    expiry_year: '',
    cvv: '',
    size: '',
    autoco: ''
  }, 
  function(items) {
    document.getElementById('name').value = items.name;
    document.getElementById("email").value = items.email;
    document.getElementById("phone").value = items.phone;
    document.getElementById("address").value = items.address;
    document.getElementById("city").value = items.city;
    document.getElementById("zip").value = items.zip;
    document.getElementById("card_type").value = items.card_type;
    document.getElementById("card_no").value = items.card_no;
    document.getElementById("expiry_month").value = items.expiry_month;
    document.getElementById("expiry_year").value = items.expiry_year;
    document.getElementById("cvv").value = items.cvv;
    document.getElementById("size").value = items.size;
    document.getElementById("autoco").checked = items.autoco;
  });
}

document.addEventListener('DOMContentLoaded', restore_options);
document.getElementById('save').addEventListener('click', save_options);